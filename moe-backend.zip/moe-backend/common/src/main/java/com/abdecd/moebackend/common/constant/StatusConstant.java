package com.abdecd.moebackend.common.constant;

public class StatusConstant {
    public static final Byte ENABLE = 1;
    public static final Byte DISABLE = 0;
}
